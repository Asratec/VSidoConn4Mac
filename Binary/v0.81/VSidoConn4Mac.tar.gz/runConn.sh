#!/bin/bash
./usr/bin/VSido.srv
