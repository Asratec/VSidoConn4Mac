#!/bin/bash
cd ./usr/bin/ && ./VSido.srv
