#!/bin/bash
cd ./usr/share/WebServer && node ./WebServer.js >/dev/null&
cd ./usr/share/WebServerNew && node ./WebServer.js >/dev/null&
